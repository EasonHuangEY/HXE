{
  "7": {
    "type": 66,
    "flags": 134217729,
    "realName": "$rowid$",
    "intDigits": 18},
  "5": {
    "type": 73,
    "flags": 16385,
    "realName": "$trex_udiv$"},
  "202": {
    "type": 83,
    "flags": 1,
    "realName": "USERLOCALE"},
  "201": {
    "type": 83,
    "flags": 17,
    "realName": "USERID"}}